
cauchypv<-function(p){
  .5-atan(mean(tan((.5-p)*pi)))/pi
}

cauchycv<-function(p){
  return(mean(tan((.5-p)*pi)))
}


ttest<-function(eps,func=colMeans,k=1/1.5)
{
  eps=as.matrix(eps)
  k=floor(nrow(eps)^k)
  folds=cut(seq(nrow(eps)),k,labels = F)
  estvar=as.matrix(sapply(seq(k),function(i)func(as.matrix(eps[folds==i,]))))
  if(ncol(estvar)>1)estvar=t(estvar)
  return(list(student=apply(estvar, 2, function(u)t.test(u)$p.value),normal=2*pnorm(-abs(mean(eps)/apply(estvar, 2, function(u)sd(u))))))
}

testbm<-function(eps,...)
{
  n=ncol(eps)
  out<-ttest(eps,...)
  sapply(out,function(u)cauchypv(u))
}
prods<-function(score,k){
  if(k>0){
    a=sapply(seq(k), function(k)rnorm(nrow(score),1,1))
    apply(as.matrix(a), 1, prod)
  }else{
    1
  }
}



getpv<-function(u,x,one, iL){
  require(sandwich)
  y=u-x[,1]
  x=cbind(x[,1],x[,-1]-x[,1])

  reg<-lm(y~x)
  regB<-lm(one~cbind(y,x)-1)
  forsn<-function(sn){
    ########
    ew1=(resid(regB))

    res=(resid((reg)))

        #alpha=0
    score=as.matrix(res*ew1)
    scoreb=score*prods(score,sn)
    scoretest3b=testbm(scoreb,k=1/3)[1]


    out<-scoretest3b
    out
  }

  out<-forsn(iL)
  out
}



SCT<-function(y,x, iL){
  one = rep(1, nrow(y))
  output0 <- apply(y, 2, getpv,x,one, iL)
  JointPV=cauchypv(output0)

  return(JointPV)
}

SCTcv<-function(y,x, iL){
  one = rep(1, nrow(y))
  output0 <- apply(y, 2, getpv,x,one, iL)
  JointCV=cauchycv(output0)

  return(JointCV)
}
