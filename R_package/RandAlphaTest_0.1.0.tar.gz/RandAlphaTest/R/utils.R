
get_AB <- function(iN){
  dB = sqrt(2*log(iN)) - (log(log(iN)) + log(4*pi))/(2*sqrt(2*log(iN)))
  dA = dB/(1+dB^2)
  return(list(A = dA, B = dB))
}

get_criticalValues_ultimate <- function(dA, dB, vAlpha){
  vCritic = dB - dA*log(-log(1.0-vAlpha))
  return(vCritic)
}



get_testStat.fast <- function(mY, mF, dNu, dTeff){
  iT = ncol(mF)
  iN = nrow(mY)
  mX = cbind(rep(1.0, iT), t(mF))

  mFoo.x =  (solve(crossprod(mX)))
  mOLS = mFoo.x%*%crossprod(mX, t(mY))
  vAlpha = mOLS[1, ]
  mRes = t(mY) - mX%*%mOLS

  vNum = abs(vAlpha)
  dDen = sqrt(mean(mRes^2))

  vPsi = (dTeff*(vNum/dDen))^(dNu/2)
  vZ = vPsi+rnorm(iN)


  return(max(vZ))
}




get_testStat.FM <- function(mY, mF, dNu){
  iT = ncol(mF)
  iN = nrow(mY)
  mX = cbind(rep(1, iT), t(mF))

  mInv <- solve(t(mX) %*% mX)  # [(k+1) x (k+1)]
  mXt <- t(mX)  # [(k+1) x iT]

  mBeta.full <- (mInv %*% mXt %*% t(mY))  # [(k+1) x iN]
  mBeta.hat <- t(mBeta.full[-1, , drop=FALSE])  # Drop intercept, transpose

  mM.N = diag(iN) - matrix(1.0, iN, iN)/iN

  # Second step, cross-sectional regression for Lambda
  vLam.hat = solve(t(mBeta.hat)%*%mM.N%*%mBeta.hat) %*% (t(mBeta.hat)%*%mM.N%*%rowMeans(mY))
  # Estimate the intercept
  vAlpha.hat = rowMeans(mY) - mBeta.hat%*%vLam.hat

  # Estimted residuals
  mFoo1 = matrix(vAlpha.hat, nrow = iN, ncol = iT)
  mRes = mY - mFoo1 - mBeta.hat%*%mV

  dS.hat = sqrt(mean(mRes^2))

  vPsi = sqrt(iT)*abs(vAlpha.hat/dS.hat)^(dNu/2)

  vZ = vPsi+rnorm(iN)

  return(max(vZ))
}



get_testStat.PC <- function(mY, mY.tilde, mV.tilde, dNu){
  iT = ncol(mY)
  iN = nrow(mY)

  mSigmaY = mY.tilde%*%t(mY.tilde)/(iT)
  lEig = eigen(mSigmaY)
  mBeta.hat = sqrt(iN)*lEig$vectors[, 1:iK]
  mF.hat =t(mBeta.hat)%*%mY.tilde/iN
  mM.N = diag(iN) - matrix(1.0, iN, iN)/iN

  # Second step, cross-sectional regression for Lambda
  mY.bar = rowMeans(mY)
  vLam.hat = solve(t(mBeta.hat)%*%mM.N%*%mBeta.hat) %*% (t(mBeta.hat)%*%mM.N%*%mY.bar)
  # Estimate the intercept
  vAlpha.hat = mY.bar - mBeta.hat%*%vLam.hat
  # Estimated residuals

  mFoo1 = matrix(vAlpha.hat, nrow = iN, ncol = iT)
  # mRes = mY - mFoo1- mBeta.hat%*%mF.hat
  mRes = mY.tilde -  mBeta.hat%*%mF.hat
  dS.hat = sqrt(mean(mRes^2))

  vPsi = min(sqrt(iT), sqrt(iN))*abs(vAlpha.hat/dS.hat)^(dNu/2)

  vZ = vPsi+rnorm(iN)

  return(max(vZ))
}


#
get_testStat_unbalanced <- function(mY, mF, dNu){

  iN = nrow(mY)
  mOut = do.call("rbind", lapply(1:iN, function(n){
    vY = mY[n, ]
    vNA.y = which(is.na(vY))
    if(length(vNA.y)>0){
      vY1 = vY[-vNA.y]
      mF1 = mF[, -vNA.y]
    } else{
      vY1 = vY
      mF1 = mF
    }
    iT = length(vY1)
    dTeff = iT^(1/dNu) # T^{1/\nu} from the paper
    if(is.null(dim(mF1))){
      mX = cbind(rep(1,iT), mF1)
    } else {
      mX = cbind(rep(1, iT), t(mF1))
      }
    vOLS = (solve(t(mX)%*%mX))%*%(t(mX)%*%vY1)
    dAlphaHat = vOLS[1]
    vRes = vY1 - mX%*%vOLS
    dSSR =  sum(vRes^2)/iT
    # dSSR =  mean(abs(vRes))
    dNum = dTeff*abs(dAlphaHat)
    # return(c(dNum, dSSR, dAlphaHat, abs(dAlphaHat)))
    return(c(dNum, dSSR))
  }))

  vNum = mOut[,1]
  dDen = sqrt(sum(mOut[,2])/iN)
  # dDen = mean(mOut[,2])

  vPsi = (vNum/dDen)^(dNu/2)
  vZ = vPsi+rnorm(iN)

  return(max(vZ))
}

get_data_latentFactor.bis <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = runif(iN, 0.7, 0.9)
    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      mEps[,t] = vGamma*vNu[t] + rnorm(iN)
    }

    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      dPerc = lInput$dPerc
      vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
      mInt[vIdx, ] = rnorm((1.0-lInput$dPerc)*iN)
    }


    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}


get_data_latentFactor_T.bis <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = runif(iN, 0.7, 0.9)
    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      mEps[,t] = vGamma*vNu[t] + rt(iN, df = 5.5)
    }

    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      dPerc = lInput$dPerc
      vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
      mInt[vIdx, ] = rnorm((1.0-lInput$dPerc)*iN)
    }



    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}



get_data_latentFactor_T.weakFactor <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = numeric(iN)
    vIdx.gamma = sample(1:iN, floor(iN^0.4), replace = F)
    vGamma[vIdx.gamma] = runif(floor(iN^0.4), 0.7, 0.9)
    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      mEps[,t] = vGamma*vNu[t] + rt(iN, df = 5.5)
    }


    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      dPerc = lInput$dPerc
      vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
      mInt[vIdx, ] = rnorm((1.0-lInput$dPerc)*iN)
    }

    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}




get_data_latentFactor_T.semiStrongFactor <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = numeric(iN)
    vIdx.gamma = sample(1:iN, floor(iN^0.8), replace = F)
    vGamma[vIdx.gamma] = runif(floor(iN^0.8), 0.7, 0.9)
    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      mEps[,t] = vGamma*vNu[t] + rt(iN, df = 5.5)
    }


    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      dPerc = lInput$dPerc
      vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
      mInt[vIdx, ] = rnorm((1.0-lInput$dPerc)*iN)
    }

    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}



get_data_latentFactor_T.semiStrongPricingFactor <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = numeric(iN)
    vBeta3 = numeric(iN)

    vIdx2 = sample(1:iN, floor(iN^(0.8)), replace=F)
    vIdx3 = sample(1:iN, floor(iN^(0.8)), replace=F)


    vBeta2[vIdx2] = runif(floor(iN^(0.8)), min = -1.0, max = 1.0)
    vBeta3[vIdx3] = runif(floor(iN^(0.8)), min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = runif(iN, 0.7, 0.9)
    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      mEps[,t] = vGamma*vNu[t] + rt(iN, df = 5.5)
    }


    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      dPerc = lInput$dPerc
      vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
      mInt[vIdx, ] = rnorm((1.0-lInput$dPerc)*iN)
    }

    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}


get_data_latentFactor_withGarch.bis <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vBetaH = runif(iN, 0.85, 0.95)
    vAlphaH = runif(iN, 0.01, 0.04)
    # vOmegaH = runif(iN, 0.1, 0.5)
    vOmegaH = runif(iN, 0.01, 0.05)
    mH = matrix(0.0, nrow = iN, ncol = iT)
    mH[,1] = vOmegaH/(rep(1.0, iN) - vBetaH - vAlphaH)

    mZ = matrix(rnorm(iT*iN), nrow = iN, ncol = iT)
    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = runif(iN, 0.7, 0.9)
    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      mH[, t] = vOmegaH + vAlphaH*mH[, t-1]*mZ[, t-1]^(2) + vBetaH*mH[,t-1]
      mEps[,t] = vGamma*vNu[t] + sqrt(mH[, t])*mZ[, t]
    }

    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      dPerc = lInput$dPerc
      vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
      mInt[vIdx, ] = rnorm((1.0-lInput$dPerc)*iN)
    }

    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}








#
#
# get_data_latentFactor.Kelly <- function(lInput){
#
#   lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
#     iT = lInput$iT
#     iK = lInput$iK
#     iN = lInput$iN
#     vIntF = lInput$vIntF
#
#     set.seed(m)
#     #Factors' innovations
#     mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)
#
#     #now simulate factors and variances
#     mF = matrix(0.0, nrow = iK, ncol = iT)
#     for(t  in 2:iT){
#       mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
#     }
#     # Loadings for the factor model
#     vBeta1 = runif(iN, min = 0.3, max = 1.8)
#     vBeta2 = runif(iN, min = -1.0, max = 1.0)
#     vBeta3 = runif(iN, min = -0.6, max = 0.9)
#     mBeta = cbind(vBeta1, vBeta2, vBeta3)
#
#
#     mEps = matrix(0.0, ncol = iT, nrow = iN)
#
#     vNu = numeric(iT)
#     dPhi.Nu = lInput$PhiNu
#     vGamma = runif(iN, 0.7, 0.9)
#     for(t  in 2:iT){
#       vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
#       mEps[,t] = vGamma*vNu[t] + rnorm(iN)
#     }
#
#     mInt = matrix(0.0, ncol = iT, nrow  = iN)
#     mInt1  = matrix(0.0, ncol = iT, nrow  = iN)
#     if(lInput$Type == "power"){
#       # dPerc = lInput$dPerc
#       # vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
#       # mInt[vIdx, ] = rnorm((1.0-lInput$dPerc)*iN)/log((iN))
#       # mInt[vIdx, ] = sample(c(0.1,-0.1), iN, T)
#       # mInt[1:(iN/2), ] = -0.1584
#       mInt[1:iN, ] = sqrt(log(iN)*log(iN)/iT)
#     }
#
#
#     mY = mInt+mBeta %*% mF + mEps
#
#     lOut = list(Y = mY, X = mF)
#     return(lOut)}, lInput = lInput)
#   return(lData)
# }
#
#
#
# get_data_Kelly <- function(lInput){
#
#   lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
#     iT = lInput$iT
#     iK = lInput$iK
#     iN = lInput$iN
#
#     set.seed(m)
#
#     #now simulate factors and variances
#     mF = matrix(rnorm(iT, 0.58, 4.04), nrow = 1, ncol = iT)
#
#     # Loadings for the factor model
#     mBeta = matrix(runif(iN, min = -3, max = 3), nrow = iN, ncol = 1)
#
#     mEps = matrix(rnorm(iT*iN), ncol = iT, nrow = iN)
#
#
#     # mAlpha=do.call(rbind, lapply(1:iN, function(i){
#     #   mX = matrix(lInput$X[i, , ], ncol = 10, nrow = iT)
#     #   vFoo = mX%*%lInput$W
#     #   return(sin(t(vFoo))/(iT^0.25))
#     #   }))
#
#
#     # mY = mAlpha+mBeta %*% mF + mEps
#     mY = mBeta %*% mF + mEps
#
#     lOut = list(Y = mY, X = mF)
#     return(lOut)}, lInput = lInput)
#   return(lData)
# }
#
#
#
#
#
#
#
#
#
#
#
#
#
#
# get_data.cali <- function(lInput){
#
#   lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
#     iT = lInput$iT
#     iN = lInput$iN
#
#     set.seed(m)
#
#     #now simulate factors and variances
#     mF = rbind(rnorm(iT, 0.77, 4.5), rnorm(iT, 0.04, 3.00), rnorm(iT, 0.14, 3.16))
#
#     # Loadings for the factor model
#     vBeta1 = runif(iN, min = 0.26, max = 2.04)
#     vBeta2 = runif(iN, min = -0.78, max = 0.75)
#     vBeta3 = runif(iN, min = -0.93, max = 1.36)
#     mBeta = cbind(vBeta1, vBeta2, vBeta3)
#
#
#     mEps =do.call(rbind, lapply(1:iN, function(i){
#       rnorm(iT, mean = 0, sd = 6.85)
#     }))
#
#     mInt = matrix(0.0, ncol = iT, nrow  = iN)
#     if(lInput$Type == "power"){
#       # mInt[1:iN, ] = rnorm(iN, 0.28, 0.32)
#       mInt[1:iN, ] = rnorm(iN, 0.373, 0.222)
#       # mInt[1:iN, ] = rnorm(iN, 1.28, 0.32)
#     }
#
#
#     mY = mInt+mBeta %*% mF + mEps
#
#     lOut = list(Y = mY, X = mF)
#     return(lOut)}, lInput = lInput)
#   return(lData)
# }
#
#
#
# get_data.cali.window <- function(lInput){
#
#   lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
#     iT = lInput$iT
#     iN = lInput$iN
#
#     set.seed(m)
#
#     #now simulate factors and variances
#     mF = rbind(rnorm(iT, 0.77, 4.5), rnorm(iT, 0.04, 3.00), rnorm(iT, 0.14, 3.16))
#
#     # Loadings for the factor model
#     vBeta1 = runif(iN, min = 0.26, max = 2.04)
#     vBeta2 = runif(iN, min = -0.78, max = 0.75)
#     vBeta3 = runif(iN, min = -0.93, max = 1.36)
#     mBeta = cbind(vBeta1, vBeta2, vBeta3)
#
#
#     mEps =do.call(rbind, lapply(1:iN, function(i){
#       rnorm(iT, mean = 0, sd = 6.85)
#     }))
#
#     mInt = matrix(0.0, ncol = iT, nrow  = iN)
#     if(lInput$Type == "power"){
#       mInt[1:iN, ] = rnorm(iN, 0.28, 0.32)
#       # mInt[1:iN, ] = rnorm(iN, 1.28, 0.32)
#     }
#
#
#     mY = mInt+mBeta %*% mF + mEps
#
#     lOut = list(Y = mY, X = mF)
#     return(lOut)}, lInput = lInput)
#   return(lData)
# }
#
#
#








get_data_latentFactor.bis_blocks <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = runif(iN, 0.7, 0.9)

    vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
    vAlpha = rnorm((1.0-lInput$dPerc)*iN)

    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      mInt[vIdx, ] = vAlpha
      }

    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      vBoo = rnorm(iN)+c(mInt[, 1]!=0)*lInput$boo*rnorm(iN)
      mEps[,t] = vGamma*vNu[t] + vBoo
    }


    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}




get_data_latentFactor.bis_blocks2 <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = runif(iN, 0.7, 0.9)

    vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
    vAlpha = rnorm((1.0-lInput$dPerc)*iN)

    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      mInt[vIdx, ] = vAlpha
    }

    vInt = mInt[,1]
    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      vBoo = rnorm(iN)*(1+abs(vInt)*lInput$boo)
      mEps[,t] = vGamma*vNu[t] + vBoo
    }


    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}



get_data_latentFactor_T.bis_blocks2 <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = runif(iN, 0.7, 0.9)

    vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
    vAlpha = rnorm((1.0-lInput$dPerc)*iN)

    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      mInt[vIdx, ] = vAlpha
    }

    vInt = mInt[,1]
    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      vBoo = rt(iN, df = 5.5)*(1+abs(vInt)*lInput$boo)/sqrt((5.5)/(5.5-2))
      mEps[,t] = vGamma*vNu[t] + vBoo
    }


    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}




get_data_latentFactor_GARCH.bis_blocks2 <- function(lInput){

  lData = parLapply(cl = cluster, 1:iM, function(m, lInput){
    iT = lInput$iT
    iK = lInput$iK
    iN = lInput$iN
    vIntF = lInput$vIntF

    set.seed(m)
    #Factors' innovations
    mZi = matrix(rnorm(iT*iK), nrow = iK, ncol = iT)

    #now simulate factors and variances
    mF = matrix(0.0, nrow = iK, ncol = iT)
    for(t  in 2:iT){
      mF[, t] = vIntF + lInput$Phi %*% mF[, t-1] + mZi[, t]
    }
    # Loadings for the factor model
    vBeta1 = runif(iN, min = 0.3, max = 1.8)
    vBeta2 = runif(iN, min = -1.0, max = 1.0)
    vBeta3 = runif(iN, min = -0.6, max = 0.9)
    mBeta = cbind(vBeta1, vBeta2, vBeta3)


    mEps = matrix(0.0, ncol = iT, nrow = iN)

    vBetaH = runif(iN, 0.85, 0.95)
    vAlphaH = runif(iN, 0.01, 0.04)

    vIdx = sample(1:iN, (1.0-lInput$dPerc)*iN, replace = F)
    vAlpha = rnorm((1.0-lInput$dPerc)*iN)
    mInt = matrix(0.0, ncol = iT, nrow  = iN)
    if(lInput$Type == "power"){
      mInt[vIdx, ] = vAlpha
    }

    vInt = mInt[,1]

    # vOmegaH = runif(iN, 0.01, 0.05)
    vOmegaH = (1.0 - vBetaH - vAlphaH)

    mH = matrix(0.0, nrow = iN, ncol = iT)
    mH[,1] = 1.0

    mZ = matrix(rnorm(iT*iN), nrow = iN, ncol = iT)
    vNu = numeric(iT)
    dPhi.Nu = lInput$PhiNu
    vGamma = runif(iN, 0.7, 0.9)


    for(t  in 2:iT){
      vNu[t] = dPhi.Nu*vNu[t-1] + rnorm(1)
      mH[, t] = vOmegaH + vAlphaH*mH[, t-1]*mZ[, t-1]^(2) + vBetaH*mH[,t-1]
      mEps[,t] = vGamma*vNu[t] + sqrt(mH[, t])*mZ[, t]*(1+abs(vInt)*lInput$boo)
    }

    mY = mInt+mBeta %*% mF + mEps

    lOut = list(Y = mY, X = mF)
    return(lOut)}, lInput = lInput)
  return(lData)
}




