
get_testStatFLLM <- function(mY, mF){
  iT = ncol(mF)
  iN = nrow(mY)
  mX = cbind(rep(1, iT), t(mF))
  mFoo = t(mF)
  mFoo1 = t(mFoo) %*% mFoo
  mFoo1.inv = solve(mFoo1)
  mFoo2 = mFoo1.inv %*% mF
  mFoo3 = mFoo %*% mFoo2
  mMf = diag(1, iT, iT) - mFoo3
  vFoo1 = mMf %*% rep(1, iT)
  dFoo1 = t(rep(1, iT)) %*% vFoo1
  mOut = do.call("rbind", lapply(1:iN, function(i){
    vOLS = (solve(t(mX)%*%mX))%*%(t(mX)%*%mY[i, ])
    dAlphaHat = vOLS[1]
    vRes = mY[i, ] - mX%*%vOLS
    dDen =  sum(vRes^(2))/(iT - nrow(mF) - 1.0)
    dNum = dAlphaHat^(2)*dFoo1
    return(c(dNum, dDen))
  }))

  dTmax = max(mOut[,1]/mOut[,2])


  return(dTmax)
}

get_testStatFLLM_unbalanced <- function(mY, mF){
  iN = nrow(mY)
  mOut = do.call("rbind", lapply(1:iN, function(i){

    vY = mY[i, ]
    vNA.y = which(is.na(vY))
    if(length(vNA.y)>0){
      vY1 = vY[-vNA.y]
      mF1 = mF[, -vNA.y]
    } else{
      vY1 = vY
      mF1 = mF
    }
    iT = length(vY1)

    if(is.null(dim(mF1))){
      mX = cbind(rep(1,iT), mF1)
      mFoo = mF1
      mFoo1 = t(mFoo) %*% mFoo
      mFoo1.inv = solve(mFoo1)
      mFoo2 = mFoo1.inv %*% mF1
      mFoo3 = mFoo %*% mFoo2
      mMf = diag(1, iT, iT) - mFoo3
      vFoo1 = mMf %*% rep(1, iT)
      dFoo1 = t(rep(1, iT)) %*% vFoo1
    } else {
      mX = cbind(rep(1, iT), t(mF1))
      mFoo = t(mF1)
      mFoo1 = t(mFoo) %*% mFoo
      mFoo1.inv = solve(mFoo1)
      mFoo2 = mFoo1.inv %*% mF1
      mFoo3 = mFoo %*% mFoo2
      mMf = diag(1, iT, iT) - mFoo3
      vFoo1 = mMf %*% rep(1, iT)
      dFoo1 = t(rep(1, iT)) %*% vFoo1
    }



    vOLS = (solve(t(mX)%*%mX))%*%(t(mX)%*%vY1)
    dAlphaHat = vOLS[1]
    vRes = vY1 - mX%*%vOLS
    dDen =  sum(vRes^(2))/(iT - nrow(mF) - 1.0)
    dNum = dAlphaHat^(2)*dFoo1
    return(c(dNum, dDen))
  }))

  dTmax = max(mOut[,1]/mOut[,2])
  return(dTmax)
}


get_criticalValuesFLLM <- function(vAlpha){
  vCritic = -log(pi) - 2*log(log(1/(1.0 - vAlpha)))
  return(vCritic)
}



get_testStatPY <- function(mY, mF){
  iT = ncol(mF)
  iN = nrow(mY)

  vOnes = rep(1, iT)
  mX = cbind(vOnes, t(mF))

  mFoo1 = crossprod(mF, ((solve(tcrossprod(mF))) %*% mF))
  mMf = diag(iT) - mFoo1
  dFoo1 = t(vOnes) %*% (mMf %*% vOnes)
  dNu = (iT - nrow(mF) - 1.0)


  mFoo.x =  (solve(crossprod(mX)))
  mOLS = mFoo.x%*%crossprod(mX, t(mY))
  vAlpha = mOLS[1, ]
  mRes = t(mY) - mX%*%mOLS

  vT2 = sapply(1:iN, function(i){
    (vAlpha[i]^(2)*dFoo1)/(sum(mRes[, i]^(2))/dNu)
  })


  dFoo = dNu/(dNu - 2.0)
  dFoo2 = 2.0*(dNu - 1.0)/(dNu - 4.0)

  #Calculation of MT estimator of correlation between residuals
  dC = qnorm(1.0 - 0.05/(2*iN))
  mC.hat = cor(mRes)
  mC.tilde = mC.hat*as.matrix(abs(sqrt(dNu)*mC.hat)>dC)
  mC.tilde[upper.tri(mC.tilde, diag = T)] = 0.0 # only sum lower triangular entries and no main diagonal
  dRho2 = (2/(iN*(iN-1)))*sum(mC.tilde^(2))

  dNum = ((iN)^(-0.5)) * sum(vT2 - dFoo)
  dDen = dFoo*sqrt(dFoo2*(1+(iN - 1)*dRho2))

  return(dNum/dDen)
}




get_testStatGRS <- function(mY, mF, iT, iN){

  mFoo = t(mF)
  vOnes = rep(1, iT)
  mX = cbind(vOnes, mFoo)

  mMf = diag(iT) - mFoo%*%((solve(mF %*% mFoo)) %*% mF)
  dFoo1 = crossprod(vOnes, mMf %*% vOnes)/iT
  mFoo.x =  (solve(crossprod(mX)))
  mOLS = mFoo.x%*%crossprod(mX, t(mY))
  vAlpha = mOLS[1, ]
  mRes = t(mY) - mX%*%mOLS
  mSigma = crossprod(mRes)/iT
  dFoo2 = crossprod(vAlpha, solve(mSigma)%*%vAlpha)
  return(dFoo1*dFoo2*(iT - iN - nrow(mF))/iN)
}

get_testStat_GOS <- function(mY, mF){
  iT = ncol(mF)
  iN = nrow(mY)

  mFoo = t(mF)
  vOnes = rep(1, iT)
  mX = cbind(vOnes, mFoo)

  mFoo1 = mFoo%*%((solve(mF %*% mFoo)) %*% mF)
  mMf = diag(1, iT, iT) - mFoo1
  dFoo1 = t(vOnes) %*% (mMf %*% vOnes)
  dNu = (iT - nrow(mF) - 1.0)

  mFoo.x =  (solve(crossprod(mX)))
  mOLS = mFoo.x%*%crossprod(mX, t(mY))
  vAlpha = mOLS[1, ]
  mRes = t(mY) - mX%*%mOLS

  vT2 = sapply(1:iN, function(i){
    (vAlpha[i]^(2)*dFoo1)/(sum(mRes[, i]^(2))/dNu)
  })

  #Calculation of BL estimator of correlation between residuals as detailed by PY in supplementary

  mSigma = cov(mRes)

  dLow = abs(min(mSigma))*(sqrt(iT/log(iN)))
  dMax = abs(max(mSigma))*(sqrt(iT/log(iN)))
  vThresholds = seq(dLow, dMax, length.out = 6)

  iS = 6 #Number of reshuffles
  iT1 = floor(2*iT/3)

  vG = numeric(length(vThresholds))
  for(i in seq(length(vG))){
    dFoo = vThresholds[i]
    s=0
    while(s<iS){
      set.seed(s)
      mU.hat = mRes[sample(nrow(mRes)), ]
      mU.hat1 = mU.hat[1:iT1, ]
      mU.hat2 = mU.hat[(iT1+1):iT, ]
      mCov1 = cov(mU.hat1)
      mCov1.thresh = mCov1*as.matrix(abs(mCov1)>dFoo*sqrt(log(iN)/iT))
      mCov2 = cov(mU.hat2)
      vG[i] = vG[i] + (norm((mCov1.thresh - mCov2), type = "F")^(2))/(iS)
      s=s+1
    }
  }
  dC = vThresholds[which.min(vG)[1]]
  dThreshold = dC*sqrt(log(iN)/iT)

  mSigma.thresh = mSigma*as.matrix(abs(mSigma)>dThreshold)
  mSigma.thresh = mSigma.thresh + diag(1e-11, iN, iN)
  mCor.thresh = cov2cor(mSigma.thresh)

  mCor.thresh[upper.tri(mCor.thresh, diag = T)] = 0.0 # only sum lower triangular entries and no main diagonal
  dRho2 = (2/(iN*(iN-1)))*sum(mCor.thresh^(2))

  dNum = ((iN)^(-0.5)) * sum(vT2 - 1.0)
  dDen = sqrt(2*(1+(iN - 1)*dRho2))

  return(dNum/dDen)
}


get_PVals_GL <- function(mY, mF){
  iT = ncol(mF)
  iN = nrow(mY)

  mFoo = t(mF)
  vOnes = rep(1, iT)
  mX.un = cbind(vOnes, mFoo)
  mX.rest = mFoo

  mOLS.un = matrix(0.0, nrow = ncol(mX.un), ncol = iN)
  mOLS.rest = matrix(0.0, nrow = ncol(mX.rest), ncol = iN)
  mRes.un = matrix(0.0, ncol = iN, nrow = iT)
  mRes.rest = matrix(0.0, ncol = iN, nrow = iT)

  vF = numeric(iN)
  for(i in 1:iN){
    vOLS.un = (solve(t(mX.un)%*%mX.un))%*%(t(mX.un)%*%mY[i, ])
    vOLS.rest = (solve(t(mX.rest)%*%mX.rest))%*%(t(mX.rest)%*%mY[i, ])
    mOLS.rest[, i] = vOLS.rest
    mOLS.un[, i] = vOLS.un
    mRes.un[, i] = mY[i, ] - mX.un%*%vOLS.un
    mRes.rest[, i] = mY[i, ] - mX.rest%*%vOLS.rest
    vF[i] = (sum(mRes.rest[, i]^(2)) - sum(mRes.un[, i]^(2)))/(sum(mRes.un[, i]^(2)))
    vF[i] = vF[i]/(iT - 1 - ncol(mX.rest))
  }

  dF.max = max(vF)
  iB = 100

  vFBC = numeric(iB - 1)
  # vFBL = numeric(iB - 1)
  vUnif = runif(iB)
  for(b in 1:(iB-1)){
    set.seed(b)
    mChi = matrix(sample(c(-0.5, 0.5), iN*iT, replace = T), nrow = iN, ncol = iT)
    mInnov = mChi*t(mRes.rest)
    mY.booty = t(mX.rest%*%mOLS.rest) + mInnov

    vFC = numeric(iN)
    # vFL = numeric(iN)
    for(i in 1:iN){
      vOLS.un = (solve(t(mX.un)%*%mX.un))%*%(t(mX.un)%*%mY.booty[i, ])
      vOLS.rest = (solve(t(mX.rest)%*%mX.rest))%*%(t(mX.rest)%*%mY.booty[i, ])
      vRes.un = mY.booty[i, ] - mX.un%*%vOLS.un
      vRes.rest = mY.booty[i, ] - mX.rest%*%vOLS.rest
      vFC[i] = (sum(mRes.rest[, i]^(2)) - sum(vRes.un^(2)))/(sum(vRes.un^(2)))
      vFC[i] = vFC[i]/(iT - 1.0 - ncol(mX.rest))
      # vFL[i] = (sum(vRes.rest^(2)) - sum(vRes.un^(2)))/(sum(vRes.un^(2)))
      # vFL[i] = vFL[i]/(iT - 1 - ncol(mX.rest))
    }
    vFBC[b] = max(vFC)
    # vFBL[b] = max(vFL)
  }

  dRC = 1+sum(as.numeric(dF.max > vFBC)) + sum(as.numeric((dF.max == vFBC) & (vUnif[iB] > vUnif[-iB])))
  # dRL = 1+sum(as.numeric(dF.max > vFBL)) + sum(as.numeric((dF.max == vFBL) & (vUnif[iB] > vUnif[-iB])))

  dPC = (iB+1-dRC)/iB
  # dPL = (iB+1-dRL)/iB
  return(dPC)
}




get_testStat_Fan <- function(mY, mF){
  iT = ncol(mF)
  iN = nrow(mY)
  dDelta = sqrt(log(iN))*log(log(iT))

  # Estimator of a, page 1511 of Fan et al
  vFoo.bar = rowMeans(mF)
  vW = solve((tcrossprod(mF))/iT) %*% vFoo.bar
  dA = 1.0 - sum(vFoo.bar*vW)

  # Estimate linear model
  mX = cbind(rep(1.0, iT), t(mF))

  mFoo.x =  (solve(crossprod(mX)))
  mOLS = mFoo.x%*%crossprod(mX, t(mY))
  vAlpha.hat = mOLS[1, ]
  mRes = t(mY) - mX%*%mOLS
  vV.hat=(colMeans(mRes^2))/(iT*dA)


  # Set of indeces \hat{S}, page 1512 of Fan et al.
  vS = which(abs(vAlpha.hat) > dDelta*sqrt(vV.hat))

  # Calculate J0, page 151 of Fan et al.
  dJ0 = ifelse(length(vS)==0, 0.0, sqrt(iN)*sum(vAlpha.hat[vS]^(2)/vV.hat[vS]))
  mRes.demean = do.call("rbind", lapply(1:iN, function(n) mRes[, n] - mean(mRes[, n])))
  # POET estimator of covariance matrix
  mSigma.hat = POET::POET(mRes.demean, K =1, thres = "soft")$SigmaY
  # Calculate J_wald, page 1513 of Fan et al.
  dJ_wald =(iT*dA*t(vAlpha.hat)%*%solve(mSigma.hat)%*%vAlpha.hat- iN)/sqrt(2*iN)

  return(dJ0 + dJ_wald)
}


